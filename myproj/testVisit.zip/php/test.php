<?php

 $phone = $_POST['user_phone'];
 $email = $_POST['user_email'];
 $check = $_POST['checkboxc'];

echo 'Данные: <br>'. $phone . '<br>'. $email . '<br>'. $check;

?>